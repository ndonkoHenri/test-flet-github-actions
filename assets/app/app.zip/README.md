# A simple-counter Flet app

An example of a counter Flet app.

To run the app:

```
flet run [app_directory]
```